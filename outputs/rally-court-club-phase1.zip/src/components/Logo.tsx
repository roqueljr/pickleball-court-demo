import { CircleDot } from "lucide-react";

export function Logo() {
  return <div className="flex items-center gap-2 font-semibold tracking-tight text-ink"><span className="grid h-9 w-9 place-items-center rounded-xl bg-lime text-pine"><CircleDot size={20} /></span><span>Rally Court Club</span></div>;
}
