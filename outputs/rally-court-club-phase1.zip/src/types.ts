export type Role = "SUPER_ADMIN" | "ADMIN" | "STAFF" | "COACH" | "CUSTOMER";
export type User = { id: string; email: string; firstName: string; lastName: string; phone: string | null; roles: Role[] };
