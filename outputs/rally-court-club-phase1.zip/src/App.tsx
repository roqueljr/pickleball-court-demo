import { BrowserRouter, Navigate, Outlet, Route, Routes, useLocation } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AuthProvider, useAuth } from "./auth/AuthProvider";
import { PublicLayout } from "./layouts/PublicLayout";
import { AppLayout } from "./layouts/AppLayout";
import { Home } from "./pages/Home";
import { Login } from "./pages/Login";
import { Register } from "./pages/Register";
import { Dashboard } from "./pages/Dashboard";
import { Placeholder } from "./pages/Placeholder";

const queryClient = new QueryClient({ defaultOptions: { queries: { refetchOnWindowFocus: false } } });

function Protected() { const { user, isLoading } = useAuth(); const location = useLocation(); if (isLoading) return <div className="grid min-h-screen place-items-center bg-sand text-ink/50">Loading Rally…</div>; return user ? <Outlet /> : <Navigate to="/login" replace state={{ from: location.pathname }} />; }

export default function App() { return <QueryClientProvider client={queryClient}><AuthProvider><BrowserRouter><Routes><Route element={<PublicLayout />}><Route path="/" element={<Home />} /><Route path="/about" element={<Placeholder />} /><Route path="/courts" element={<Placeholder />} /><Route path="/memberships" element={<Placeholder />} /><Route path="/coaches" element={<Placeholder />} /><Route path="/contact" element={<Placeholder />} /><Route path="/faq" element={<Placeholder />} /><Route path="/login" element={<Login />} /><Route path="/register" element={<Register />} /></Route><Route element={<Protected />}><Route path="/app" element={<AppLayout />}><Route index element={<Dashboard />} /><Route path="book" element={<Placeholder />} /><Route path="bookings" element={<Placeholder />} /><Route path="customers" element={<Placeholder />} /><Route path="reports" element={<Placeholder />} /><Route path="settings" element={<Placeholder />} /><Route path="payments" element={<Placeholder />} /><Route path="profile" element={<Placeholder />} /></Route></Route><Route path="*" element={<Navigate to="/" replace />} /></Routes></BrowserRouter></AuthProvider></QueryClientProvider>; }
