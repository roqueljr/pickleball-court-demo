import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { BarChart3, CalendarDays, CircleUserRound, CreditCard, LayoutDashboard, LogOut, Menu, Settings, ShoppingBag, Users, X } from "lucide-react";
import { useState } from "react";
import { Logo } from "../components/Logo";
import { Button } from "../components/Button";
import { useAuth } from "../auth/AuthProvider";
import { cn } from "../lib/cn";

export function AppLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const role = user?.roles[0] ?? "CUSTOMER";
  const isAdmin = role === "SUPER_ADMIN" || role === "ADMIN";
  const isStaff = isAdmin || role === "STAFF";
  const links = [
    { to: "/app", label: "Overview", icon: LayoutDashboard },
    { to: "/app/bookings", label: "Bookings", icon: CalendarDays },
    ...(isStaff ? [{ to: "/app/customers", label: "Customers", icon: Users }] : []),
    ...(isAdmin ? [{ to: "/app/reports", label: "Reports", icon: BarChart3 }, { to: "/app/settings", label: "Settings", icon: Settings }] : []),
    { to: "/app/payments", label: "Payments", icon: CreditCard },
    { to: "/app/profile", label: "Profile", icon: CircleUserRound }
  ];
  async function signOut() { await logout(); navigate("/"); }
  return <div className="min-h-screen bg-sand text-ink"><aside className={cn("fixed inset-y-0 left-0 z-30 w-72 border-r border-black/5 bg-white p-5 transition-transform lg:translate-x-0", open ? "translate-x-0" : "-translate-x-full")}><div className="flex items-center justify-between"><Link to="/app" onClick={() => setOpen(false)}><Logo /></Link><button className="lg:hidden" onClick={() => setOpen(false)} aria-label="Close menu"><X size={20} /></button></div><div className="mt-10 space-y-1">{links.map(({ to, label, icon: Icon }) => <NavLink key={to} to={to} end={to === "/app"} onClick={() => setOpen(false)} className={({ isActive }) => cn("flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium", isActive ? "bg-pine text-white" : "text-ink/60 hover:bg-sand hover:text-ink")}><Icon size={18} />{label}</NavLink>)}</div><div className="absolute inset-x-5 bottom-5 rounded-2xl bg-sand p-3"><div className="mb-3 flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-full bg-coral text-sm font-bold text-white">{user?.firstName.slice(0, 1)}</div><div className="min-w-0"><p className="truncate text-sm font-semibold">{user?.firstName} {user?.lastName}</p><p className="text-xs text-ink/50">{role.replace("_", " ")}</p></div></div><Button variant="ghost" className="flex w-full items-center justify-start gap-2 px-2" onClick={() => void signOut()}><LogOut size={16} /> Sign out</Button></div></aside><div className="lg:pl-72"><header className="sticky top-0 z-20 flex items-center justify-between border-b border-black/5 bg-sand/90 px-5 py-4 backdrop-blur lg:px-8"><button className="lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu"><Menu /></button><div className="hidden lg:block"><p className="text-sm text-ink/50">{isAdmin ? "Operations center" : "Member space"}</p></div><div className="flex items-center gap-3"><Link to="/app/book" className="hidden rounded-xl bg-lime px-4 py-2 text-sm font-bold text-pine sm:block"><ShoppingBag size={16} className="mr-2 inline" />Book a court</Link><div className="grid h-9 w-9 place-items-center rounded-full bg-pine text-sm font-bold text-white">{user?.firstName.slice(0, 1)}</div></div></header><main className="mx-auto max-w-7xl px-5 py-8 lg:px-8"><Outlet /></main></div></div>;
}
