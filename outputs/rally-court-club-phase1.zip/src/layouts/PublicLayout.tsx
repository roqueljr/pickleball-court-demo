import { Link, Outlet } from "react-router-dom";
import { Logo } from "../components/Logo";

export function PublicLayout() {
  return <div className="min-h-screen bg-white text-ink"><header className="border-b border-black/5 bg-white/90"><div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8"><Link to="/"><Logo /></Link><nav className="hidden items-center gap-7 text-sm text-ink/70 md:flex"><Link to="/courts">Courts</Link><Link to="/memberships">Memberships</Link><Link to="/coaches">Coaches</Link><Link to="/about">About</Link></nav><div className="flex items-center gap-2"><Link className="rounded-xl px-3 py-2 text-sm font-semibold text-ink/70 hover:bg-sand" to="/login">Sign in</Link><Link className="rounded-xl bg-pine px-4 py-2.5 text-sm font-semibold text-white" to="/register">Join the club</Link></div></div></header><Outlet /><footer className="border-t border-black/5 px-5 py-8 text-sm text-ink/50"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-3 md:flex-row"><span>© 2026 Rally Court Club</span><span>Premium courts. Better rallies.</span></div></footer></div>;
}
