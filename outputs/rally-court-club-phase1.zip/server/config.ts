import "dotenv/config";

export const config = {
  nodeEnv: process.env.NODE_ENV ?? "development",
  port: Number(process.env.PORT ?? 4000),
  appUrl: process.env.APP_URL ?? "http://localhost:5173",
  jwtSecret: process.env.JWT_SECRET ?? "development-only-change-me",
  cookieName: "rally_access_token",
  accessTokenTtl: "15m"
} as const;
