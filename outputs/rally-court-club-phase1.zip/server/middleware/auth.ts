import type { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import type { RoleCode } from "@prisma/client";
import { config } from "../config.js";
import { AppError } from "../utils/errors.js";

type Token = { sub: string; email: string; roles: RoleCode[] };

export function signAccessToken(payload: Token) {
  return jwt.sign(payload, config.jwtSecret, { expiresIn: config.accessTokenTtl });
}

export function authenticate(req: Request, _res: Response, next: NextFunction) {
  const token = req.cookies?.[config.cookieName] as string | undefined;
  if (!token) return next(new AppError(401, "Authentication required."));
  try {
    const payload = jwt.verify(token, config.jwtSecret) as Token;
    req.auth = { userId: payload.sub, email: payload.email, roles: payload.roles };
    next();
  } catch {
    next(new AppError(401, "Your session has expired. Please sign in again."));
  }
}

export function authorize(...allowedRoles: RoleCode[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.auth || !req.auth.roles.some((role) => allowedRoles.includes(role))) {
      next(new AppError(403, "You do not have permission to perform this action."));
      return;
    }
    next();
  };
}
