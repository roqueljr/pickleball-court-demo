import { Router, type Response } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "../db.js";
import { config } from "../config.js";
import { AppError } from "../utils/errors.js";
import { authenticate, signAccessToken } from "../middleware/auth.js";

export const authRouter = Router();

const credentialsSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  password: z.string().min(8).max(128)
});

const registerSchema = credentialsSchema.extend({
  firstName: z.string().trim().min(1).max(80),
  lastName: z.string().trim().min(1).max(80),
  phone: z.string().trim().max(30).optional()
});

function setAuthCookie(res: Response, token: string) {
  res.cookie(config.cookieName, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: config.nodeEnv === "production",
    maxAge: 15 * 60 * 1000,
    path: "/"
  });
}

function publicUser(user: { id: string; email: string; firstName: string; lastName: string; phone: string | null; roles: { role: { code: string } }[] }) {
  return {
    id: user.id,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
    phone: user.phone,
    roles: user.roles.map(({ role }) => role.code)
  };
}

authRouter.post("/register", async (req, res, next) => {
  try {
    const input = registerSchema.parse(req.body);
    const exists = await prisma.user.findUnique({ where: { email: input.email } });
    if (exists) throw new AppError(409, "An account with this email already exists.");
    const passwordHash = await bcrypt.hash(input.password, 12);
    const role = await prisma.role.findUnique({ where: { code: "CUSTOMER" } });
    if (!role) throw new AppError(500, "Customer role is not configured.");
    const user = await prisma.user.create({
      data: {
        email: input.email,
        passwordHash,
        firstName: input.firstName,
        lastName: input.lastName,
        phone: input.phone,
        customer: { create: {} },
        roles: { create: { roleId: role.id } }
      },
      include: { roles: { include: { role: true } } }
    });
    const token = signAccessToken({ sub: user.id, email: user.email, roles: ["CUSTOMER"] });
    setAuthCookie(res, token);
    res.status(201).json({ success: true, data: { user: publicUser(user) } });
  } catch (error) { next(error); }
});

authRouter.post("/login", async (req, res, next) => {
  try {
    const input = credentialsSchema.parse(req.body);
    const user = await prisma.user.findUnique({ where: { email: input.email }, include: { roles: { include: { role: true } } } });
    if (!user || !(await bcrypt.compare(input.password, user.passwordHash))) throw new AppError(401, "Invalid email or password.");
    if (user.status !== "ACTIVE") throw new AppError(403, "This account is not active.");
    const roles = user.roles.map(({ role }) => role.code as import("@prisma/client").RoleCode);
    await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    const token = signAccessToken({ sub: user.id, email: user.email, roles });
    setAuthCookie(res, token);
    res.json({ success: true, data: { user: publicUser(user) } });
  } catch (error) { next(error); }
});

authRouter.post("/logout", (_req, res) => {
  res.clearCookie(config.cookieName, { httpOnly: true, sameSite: "lax", secure: config.nodeEnv === "production", path: "/" });
  res.json({ success: true, data: null });
});

authRouter.get("/me", authenticate, async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.auth!.userId }, include: { roles: { include: { role: true } } } });
    if (!user) throw new AppError(401, "User account not found.");
    res.json({ success: true, data: { user: publicUser(user) } });
  } catch (error) { next(error); }
});
