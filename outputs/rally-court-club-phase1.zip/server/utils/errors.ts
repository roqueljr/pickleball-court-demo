import type { ErrorRequestHandler, RequestHandler } from "express";
import { ZodError } from "zod";

export class AppError extends Error {
  constructor(public statusCode: number, message: string, public errors: Record<string, unknown> = {}) {
    super(message);
    this.name = "AppError";
  }
}

export const notFound: RequestHandler = (_req, _res, next) => next(new AppError(404, "Route not found"));

export const errorHandler: ErrorRequestHandler = (error, _req, res, _next) => {
  void _next;
  if (error instanceof ZodError) {
    res.status(400).json({ success: false, message: "Validation failed.", errors: error.flatten().fieldErrors });
    return;
  }
  if (error instanceof AppError) {
    res.status(error.statusCode).json({ success: false, message: error.message, errors: error.errors });
    return;
  }
  console.error(error);
  res.status(500).json({ success: false, message: "An unexpected server error occurred.", errors: {} });
};
