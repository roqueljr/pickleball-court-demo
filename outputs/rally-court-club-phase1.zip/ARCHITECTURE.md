# Architecture

## Frontend

The `src` tree is organized around `layouts`, `pages`, `components`, `auth`, and `lib`. `AuthProvider` owns the current session query and login/register/logout mutations. `AppLayout` is the role-aware shell; route visibility is derived from roles returned by the API, while the API remains the authorization source of truth. TanStack Query is the server-state boundary for future courts, bookings, payments, and reporting queries.

## Backend

`server/app.ts` owns cross-cutting middleware. `server/routes` exposes versionable API namespaces. Authentication is implemented in `server/routes/auth.ts`, with `server/middleware/auth.ts` responsible for JWT verification and role gates. Errors use a single `{ success, message, errors }` response contract. Domain controllers/services will be added by phase without moving auth or database concerns into the UI.

## Database

Prisma models cover identity, customers, staff, coaches, courts, schedules, bookings, payments, memberships, promotions, coaching, rentals, products, sales, expenses, notifications, settings, and audit logs. Foreign keys and indexes are defined in the schema. Booking overlap is protected by a PostgreSQL GiST exclusion constraint in `prisma/booking-overlap.sql`, which complements the transaction-level conflict check that will be added with the booking service.

## Authentication and authorization

Passwords are hashed with bcrypt. Access tokens are short-lived JWTs stored in an HTTP-only cookie. The browser never receives a token to store in localStorage. API middleware verifies the cookie and attaches a minimal user identity to the request; `authorize(...)` gates role-sensitive endpoints. Password reset and email verification will use one-time hashed tokens in Phase 4 when the email adapter is introduced.

## Booking boundary

Booking creation will validate court status, operating hours, advance-booking rules, membership and promotion benefits, tax, and conflicts inside one database transaction. The PostgreSQL exclusion constraint is the final concurrency guard. Cancellations, refunds, check-in, and audit entries will be explicit commands rather than generic record updates.

## External services

Email and payment providers are represented by configuration variables and will be added behind adapters. Local development can record manual payments and create in-app notifications without provider credentials; production adapters can be enabled without changing booking or membership domain code.
