import bcrypt from "bcryptjs";
import { PrismaClient, RoleCode, CourtStatus } from "@prisma/client";

const prisma = new PrismaClient();
const demoPassword = "ChangeMe123!";

async function main() {
  const permissions = ["dashboard.view", "bookings.manage", "courts.manage", "customers.manage", "payments.manage", "reports.view", "settings.manage", "users.manage"];
  const permissionRows = await Promise.all(permissions.map((key) => prisma.permission.upsert({ where: { key }, update: {}, create: { key, description: key.replace(".", " ") } })));
  const roleNames: Record<RoleCode, string> = { SUPER_ADMIN: "Super Admin", ADMIN: "Admin", STAFF: "Staff", COACH: "Coach", CUSTOMER: "Customer" };
  const roles = {} as Record<RoleCode, { id: string }>;
  for (const code of Object.values(RoleCode)) {
    const role = await prisma.role.upsert({ where: { code }, update: { name: roleNames[code] }, create: { code, name: roleNames[code] } });
    roles[code] = role;
    if (code === "SUPER_ADMIN" || code === "ADMIN") await Promise.all(permissionRows.map((permission) => prisma.rolePermission.upsert({ where: { roleId_permissionId: { roleId: role.id, permissionId: permission.id } }, update: {}, create: { roleId: role.id, permissionId: permission.id } })));
  }

  async function user(email: string, firstName: string, lastName: string, role: RoleCode, profile: "customer" | "staff" | "coach" | null = null) {
    const passwordHash = await bcrypt.hash(demoPassword, 12);
    return prisma.user.upsert({ where: { email }, update: {}, create: { email, firstName, lastName, passwordHash, emailVerifiedAt: new Date(), roles: { create: { roleId: roles[role].id } }, ...(profile === "customer" ? { customer: { create: {} } } : {}), ...(profile === "staff" ? { staff: { create: {} } } : {}), ...(profile === "coach" ? { coach: { create: { biography: "Certified coach focused on confidence and consistency.", experience: "8 years", certifications: "PPR Certified", hourlyRate: 900 } } } : {}) } });
  }
  const superAdmin = await user("admin@example.com", "Alex", "Santos", "SUPER_ADMIN");
  await user("manager@example.com", "Mia", "Reyes", "ADMIN");
  await user("staff@example.com", "Sam", "Cruz", "STAFF", "staff");
  await user("customer@example.com", "Jamie", "Lim", "CUSTOMER", "customer");
  await user("coach@example.com", "Taylor", "Dela Cruz", "COACH", "coach");

  const courts = [
    ["Court 1", "Indoor tournament court", "North Hall", true, 650],
    ["Court 2", "Indoor training court", "North Hall", true, 650],
    ["Court 3", "Open-air social court", "Garden Wing", false, 500],
    ["Court 4", "Open-air feature court", "Garden Wing", false, 500]
  ] as const;
  for (const [name, description, location, indoor, hourlyRate] of courts) await prisma.court.upsert({ where: { name }, update: {}, create: { name, description, location, indoor, hourlyRate, status: CourtStatus.AVAILABLE, surfaceType: "Acrylic sport surface", features: ["LED lighting", "Benches", "Water station"] } });
  const plans = [["Regular", "Pay as you play.", 0, 30], ["Silver", "A little more play for a little less.", 10, 30], ["Gold", "For members who keep the rally going.", 20, 365], ["Premium", "The full club experience.", 30, 365]] as const;
  for (const [name, description, discountPercent, durationDays] of plans) await prisma.membershipPlan.upsert({ where: { name }, update: {}, create: { name, description, discountPercent, durationDays, price: name === "Regular" ? 0 : name === "Silver" ? 799 : name === "Gold" ? 2499 : 4999 } });
  const categories = ["Paddles", "Balls", "Apparel", "Drinks"];
  for (const name of categories) await prisma.productCategory.upsert({ where: { name }, update: {}, create: { name } });
  await prisma.product.upsert({ where: { sku: "BALL-001" }, update: {}, create: { sku: "BALL-001", name: "Rally outdoor balls", price: 220, cost: 120, stock: 48, lowStockThreshold: 10 } });
  await prisma.product.upsert({ where: { sku: "DRINK-001" }, update: {}, create: { sku: "DRINK-001", name: "Club hydration", price: 80, cost: 30, stock: 80, lowStockThreshold: 12 } });
  await prisma.equipment.upsert({ where: { id: "demo-paddle" }, update: {}, create: { id: "demo-paddle", name: "Demo paddle", quantity: 12, availableQuantity: 12, rentalPrice: 150 } });
  const settings = { business_name: "Rally Court Club", currency: "PHP", timezone: "Asia/Manila", tax_rate: 0.12, minimum_booking_minutes: 60, maximum_booking_minutes: 180, cancellation_hours: 12, minimum_advance_minutes: 60, maximum_advance_days: 30 };
  for (const [key, value] of Object.entries(settings)) await prisma.businessSetting.upsert({ where: { key }, update: { value }, create: { key, value } });
  await prisma.auditLog.create({ data: { userId: superAdmin.id, action: "SEED_COMPLETED", entity: "SYSTEM", metadata: { demo: true } } });
  console.log(`Seeded Rally Court Club. Demo password: ${demoPassword}`);
}

main().catch((error) => { console.error(error); process.exit(1); }).finally(() => prisma.$disconnect());
