-- Apply this SQL after the Prisma migration to make PostgreSQL reject overlapping
-- court bookings at the database layer. The service layer still returns a friendly
-- conflict error before attempting the write.
CREATE EXTENSION IF NOT EXISTS btree_gist;
ALTER TABLE "Booking"
  ADD CONSTRAINT "booking_no_overlap"
  EXCLUDE USING gist (
    "courtId" WITH =,
    tstzrange("startsAt", "endsAt", '[)') WITH &&
  )
  WHERE ("status" IN ('PENDING', 'CONFIRMED', 'CHECKED_IN'));
