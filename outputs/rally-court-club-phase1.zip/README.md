# Rally Court Club

Rally Court Club is a full-stack pickleball business management and court booking system. The repository is being delivered in phases; Phase 1 establishes the production-oriented foundation: React/Vite frontend, Express API, Prisma/PostgreSQL schema, secure password authentication, role-aware navigation, seed data, and consistent API errors.

## Stack

- React + TypeScript + Vite
- Tailwind CSS with reusable shadcn-style primitives
- React Router, TanStack Query, React Hook Form, Zod, Lucide
- Node.js + Express + TypeScript
- PostgreSQL + Prisma
- bcrypt password hashing, HTTP-only JWT cookie, Helmet, CORS, rate limiting

## Local setup

1. Copy `.env.example` to `.env` and set `DATABASE_URL`.
2. Create the PostgreSQL database named in the URL.
3. Install dependencies: `npm install`.
4. Generate Prisma Client: `npm run db:generate`.
5. Apply the schema: `npm run db:push` for local development or `npm run db:migrate` for migration history.
6. Apply `prisma/booking-overlap.sql` after the first migration to add PostgreSQL's exclusion constraint for overlapping court reservations.
7. Seed development data: `npm run db:seed`.
8. Start frontend and API together: `npm run dev`.

The frontend runs at http://localhost:5173 and the API runs at http://localhost:4000.

## Demo accounts

These are development-only accounts created by the seed script. The password for all accounts is `ChangeMe123!`; change it before any production use.

| Role | Email |
|---|---|
| Super Admin | admin@example.com |
| Admin | manager@example.com |
| Staff | staff@example.com |
| Customer | customer@example.com |
| Coach | coach@example.com |

## Useful commands

`npm run typecheck` · `npm run build` · `npm run lint` · `npm test` · `npm run db:studio`

## Deployment notes

Set production environment variables, run `npm run db:migrate`, run `npm run build` and `npm run build:server`, then start the API with `npm start`. Serve the Vite `dist` directory from the deployment platform or configure the platform to serve the SPA fallback. Replit-compatible environment variables are used; no secrets are committed.

See [ARCHITECTURE.md](./ARCHITECTURE.md) for the detailed application boundaries and [prisma/schema.prisma](./prisma/schema.prisma) for the normalized relational model.
